package com.ramaguru.amrita.cys.jpl.datastructures;

import java.util.HashMap;

public class hashmapexample1 {

    public static void main(String[] args) {

        HashMap<String, String> rollName = new HashMap<String, String>();

        rollName.put("CB.EN.U4CYS21001", "Abinesh G");
        rollName.put("CB.EN.U4CYS21011", "A S Deepan");
        rollName.put("CB.EN.U4CYS21021", "Gundala Kushal Bhavani Reddy");
        rollName.put("CB.EN.U4CYS21031", "Kishanth K");
        rollName.put("CB.EN.U4CYS21041", "Middivari Charan Kumar Reddy");
        rollName.put("CB.EN.U4CYS21051", "Nithin S");
        rollName.put("CB.EN.U4CYS21061", "Roshni V");
        rollName.put("CB.EN.U4CYS21071", "Sourabh Sasikanthan");
        rollName.put("CB.EN.U4CYS21081", "Koti Venkatadinesh Reddy");
        rollName.put("CB.EN.U4CYS21079", "Swetha V");

        // Retrieve and print the name associated with a specific roll number
        String rollNumber = "CB.EN.U4CYS21079";
        String name = rollName.get(rollNumber);
        System.out.println("Name: " + name);

        // Check if a specific roll number exists in the HashMap
        boolean exists = rollName.containsKey("CB.EN.U4CYS21061");
        System.out.println("Roll number CB.EN.U4CYS21061 exists: " + exists);

        // Remove a key-value pair from the HashMap
        String removedName = rollName.remove("CB.EN.U4CYS21031");
        System.out.println("Removed name: " + removedName);


        // Get the size of the HashMap
        int size = rollName.size();
        System.out.println("Size of the HashMap: " + size);
    }
}
