package com.ramaguru.amrita.cys.jpl.datastructures;

public class arrayexample1 {
    public static void main(String args[]) {
        String rollNumber[] = new String[6];

        rollNumber[0] = "CB.EN.U4CYS21021";
        rollNumber[1] = "CB.EN.U4CYS21022";
        rollNumber[2] = "CB.EN.U4CYS21023";
        rollNumber[3] = "CB.EN.U4CYS21024";
        rollNumber[4] = "CB.EN.U4CYS21025";
        rollNumber[5] = "CB.EN.U4CYS21079";

        // Print the elements of the array
        System.out.println("Elements of the array:");
        for (int i = 0; i < rollNumber.length; i++) {
            System.out.println(rollNumber[i]);
        }

        // Get the length of the array
        int length = rollNumber.length;
        System.out.println("Length of the array: " + length);

        // Access the first and last elements of the array
        String firstElement = rollNumber[0];
        String lastElement = rollNumber[length - 1];
        System.out.println("First element: " + firstElement);
        System.out.println("Last element: " + lastElement);

        // Update an element in the array
        rollNumber[2] = "CB.EN.U4CYS22030";
        System.out.println("Updated element at index 2: " + rollNumber[2]);

        // Search for an element in the array
        String searchElement = "CB.EN.U4CYS21079";
        int index = -1;
        for (int i = 0; i < rollNumber.length; i++) {
            if (rollNumber[i].equals(searchElement)) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            System.out.println("Element found at index: " + index);
        } else {
            System.out.println("Element not found in the array.");
        }
    }
}
