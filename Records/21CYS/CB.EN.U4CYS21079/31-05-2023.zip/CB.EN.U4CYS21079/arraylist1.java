package com.ramaguru.amrita.cys.jpl.datastructures;

import java.util.ArrayList;
import java.util.Iterator;

public class arraylist1 {

    public static void main(String[] args) {

        ArrayList<String> u21cys = new ArrayList<String>();

        u21cys.add("CB.EN.U4CYS22026");
        u21cys.add("CB.EN.U4CYS22027");
        u21cys.add("CB.EN.U4CYS22028");
        u21cys.add("CB.EN.U4CYS22029");
        u21cys.add("CB.EN.U4CYS22030");

        // Print all elements using Iterator
        System.out.println("Printing all elements using Iterator:");
        Iterator<String> it = u21cys.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        // Remove an element
        String removedElement = u21cys.remove(2);
        System.out.println("Removed element: " + removedElement);

        // Add an element at a specific index
        u21cys.add(2, "CB.EN.U4CYS22031");
        System.out.println("ArrayList after adding an element at index 2:");
        for (String element : u21cys) {
            System.out.println(element);
        }

        // Check if an element exists in the ArrayList
        String searchElement = "CB.EN.U4CYS22079";
        boolean exists = u21cys.contains(searchElement);
        System.out.println("Element " + searchElement + " exists in the ArrayList: " + exists);

        // Get the size of the ArrayList
        int size = u21cys.size();
        System.out.println("Size of the ArrayList: " + size);
    }
}
