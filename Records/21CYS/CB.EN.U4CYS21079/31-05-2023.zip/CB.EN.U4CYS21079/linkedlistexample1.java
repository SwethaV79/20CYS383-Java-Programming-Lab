package com.ramaguru.amrita.cys.jpl.datastructures;

import java.util.LinkedList;

public class linkedlistexample1 {

    public static void main(String[] args) {
        LinkedList<String> u21cys = new LinkedList<String>();

        u21cys.add("CB.EN.U4CYS22031");
        u21cys.add("CB.EN.U4CYS22032");
        u21cys.add("CB.EN.U4CYS22033");
        u21cys.add("CB.EN.U4CYS22034");
        u21cys.add("CB.EN.U4CYS22035");
        u21cys.add("CB.EN.U4CYS22079");

        // Print the LinkedList
        System.out.println("LinkedList: " + u21cys);

        // Get the size of the LinkedList
        int size = u21cys.size();
        System.out.println("Size of the LinkedList: " + size);

        // Check if the LinkedList is empty
        boolean isEmpty = u21cys.isEmpty();
        System.out.println("Is the LinkedList empty? " + isEmpty);

        // Access the first and last elements of the LinkedList
        String firstElement = u21cys.getFirst();
        String lastElement = u21cys.getLast();
        System.out.println("First element: " + firstElement);
        System.out.println("Last element: " + lastElement);

         // Iterate through the LinkedList using a for-each loop
        System.out.println("Iterating through the LinkedList:");
        for (String element : u21cys) {
            System.out.println(element);
        }
    }
}
