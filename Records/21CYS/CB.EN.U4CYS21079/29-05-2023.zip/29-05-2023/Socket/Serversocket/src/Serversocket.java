import java.io.*;
import java.net.*;

public class Serversocket {
    public static void main(String[] args) {
        try {
            ServerSocket ss = new ServerSocket(2444);
            Socket s = ss.accept();

            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            String receivedMessage = "";
            String sendMessage = "";

            while (!sendMessage.equals("exit")) {
                receivedMessage = dis.readUTF();
                System.out.println("Client: " + receivedMessage);

                // Read input from the server console
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Server: ");
                sendMessage = br.readLine();

                dos.writeUTF(sendMessage);
                dos.flush();
            }

            ss.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
}
