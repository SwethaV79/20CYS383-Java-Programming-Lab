import java.io.*;
import java.net.*;

public class Clientsocket {
    public static void main(String[] args) {
        try {
            Socket s = new Socket("localhost", 2444);

            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            String receivedMessage = "";
            String sendMessage = "";

            while (!receivedMessage.equals("exit")) {
                // Read input from the client console
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Client: ");
                sendMessage = br.readLine();

                dos.writeUTF(sendMessage);
                dos.flush();

                receivedMessage = dis.readUTF();
                System.out.println("Server: " + receivedMessage);
            }

            s.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
}
