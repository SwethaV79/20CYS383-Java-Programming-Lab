package com.ramaguru.amrita.cys.jpl.gui.swing.layout;

import javax.swing.*;
import java.awt.*;

public class Studentform extends JFrame {
    /**
     * Student form that accepts 5 inputs based on flow layout
     *
     */

    public Studentform() {
        setTitle("Student Registration Form");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Create a panel for each field
        JPanel namePanel = new JPanel(new FlowLayout());
        JPanel rollNumberPanel = new JPanel(new FlowLayout());
        JPanel coursePanel = new JPanel(new FlowLayout());
        JPanel emailPanel = new JPanel(new FlowLayout());

        // Labels
        JLabel nameLabel = new JLabel("Name:");
        JLabel rollNumberLabel = new JLabel("Roll Number:");
        JLabel courseLabel = new JLabel("Course:");
        JLabel emailLabel = new JLabel("Email:");

        // Text fields
        JTextField nameTextField = new JTextField(20);
        JTextField rollNumberTextField = new JTextField(10);
        JTextField courseTextField = new JTextField(15);
        JTextField emailTextField = new JTextField(25);

        // Add components to respective panels
        namePanel.add(nameLabel);
        namePanel.add(nameTextField);

        rollNumberPanel.add(rollNumberLabel);
        rollNumberPanel.add(rollNumberTextField);

        coursePanel.add(courseLabel);
        coursePanel.add(courseTextField);

        emailPanel.add(emailLabel);
        emailPanel.add(emailTextField);

        // Add panels to the content pane
        add(namePanel);
        add(rollNumberPanel);
        add(coursePanel);
        add(emailPanel);

        // Button
        JButton submitButton = new JButton("Submit");
        add(submitButton);

        setVisible(true);
    }

    public static void main(String[] args) {
        new Studentform();
    }
}
