package com.amrita.jpl.P1_21079;

import java.util.Scanner;

public class JPL_P1_21079 {

    /**
     * The main method of the program that provides the menu-driven interface and calls
     * the required helper methods based on the user's choice.
     *
         */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("Enter your choice:");
            System.out.println("1. Factorial (fact)");
            System.out.println("2. Fibonacci (fib)");
            System.out.println("3. The sum of 'n' numbers (sum n no)");
            System.out.println("4. Prime Test (prime test)");
            System.out.println("0. Exit");
            choice = sc.nextInt();

            switch (choice) {
                case 1 -> {
                    /**
                     * Calculates the factorial of a given number.
                     *
                     * @param n the input number whose factorial is to be calculated
                     * @return the factorial of the input number
                     */
                    System.out.print("Enter a number: ");
                    int num1 = sc.nextInt();
                    if (num1 < 0) {
                        System.out.println("Invalid input. Number should be non-negative.");
                    } else {
                        int fact = factorial(num1);
                        System.out.println("Factorial of " + num1 + " is " + fact);
                    }
                }
                case 2 -> {
                    /**
                     * Displays the Fibonacci series up to a given term.
                     *
                     * @param n the number of terms in the Fibonacci series to be displayed
                     */
                    System.out.print("Enter a number: ");
                    int num2 = sc.nextInt();
                    if (num2 < 0) {
                        System.out.println("Invalid input. Number should be non-negative.");
                    } else {
                        fibonacci(num2);
                    }
                }
                case 3 -> {
                    /**
                     * Calculates the sum of the first 'n' numbers.
                     *
                     * @param n the value of 'n' for which the sum is to be calculated
                     * @return the sum of the first 'n' numbers
                     */
                    System.out.print("Enter the value of n: ");
                    int n = sc.nextInt();
                    if (n < 0) {
                        System.out.println("Invalid input. n should be non-negative.");
                    } else {
                        int sum = sumOfNumbers(n);
                        System.out.println("Sum of first " + n + " numbers is " + sum);
                    }
                }
                case 4 -> {
                    /**
                     * Tests whether a given number is prime or not.
                     *
                     * @param n the input number to be tested
                     * @return true if the input number is prime, false otherwise
                     */
                    System.out.print("Enter a number: ");
                    int num3 = sc.nextInt();
                    if (num3 <= 1) {
                        System.out.println("Invalid input. Number should be non-negative");
                    } else if (num3 == 2) {
                        System.out.println(num3 + " is a prime number.");
                    } else {
                        boolean isPrime = isPrime(num3);
                        if (isPrime) {
                            System.out.println(num3 + " is a prime number.");
                        } else {
                            System.out.println(num3 + " is not a prime number.");
                        }
                    }
                }
                case 0 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

        sc.close();
    }

    public static int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        }
        return n * factorial(n - 1);
    }

    public static void fibonacci(int n) {
        int a = 0, b = 1, c;
        System.out.print("Fibonacci series upto " + n + " terms: ");
        for (int i = 1; i <= n; i++) {
            System.out.print(a + " ");
            c = a + b;
            a = b;
            b = c;
        }
        System.out.println();
    }

    public static int sumOfNumbers(int n) {
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        return sum;
    }

    public static boolean isPrime(int n) {
        if (n <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }
        return true;
    }
}
