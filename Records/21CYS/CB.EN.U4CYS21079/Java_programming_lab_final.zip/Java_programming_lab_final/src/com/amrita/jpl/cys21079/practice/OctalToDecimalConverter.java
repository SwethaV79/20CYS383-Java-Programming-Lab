package com.amrita.jpl.cys21079.practice;

import java.util.Scanner;

public class OctalToDecimalConverter {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter an octal number: ");
        String octal = input.nextLine();

        int decimal = 0;
        int power = 0;

        for (int i = octal.length() - 1; i >= 0; i--) {
            int digit = Character.getNumericValue(octal.charAt(i));
            decimal += digit * Math.pow(8, power);
            power++;
        }

        System.out.println("Decimal equivalent of " + octal + " is " + decimal);
    }
}
