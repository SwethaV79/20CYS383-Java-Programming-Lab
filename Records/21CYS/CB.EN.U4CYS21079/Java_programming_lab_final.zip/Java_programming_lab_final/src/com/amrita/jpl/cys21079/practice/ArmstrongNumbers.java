package com.amrita.jpl.cys21079.practice;

import java.util.Scanner;

public class ArmstrongNumbers {
    /**
     * class to check number of armstrong numbers in a given range
     *
     */

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the lower limit: ");
        int lower = input.nextInt();
        System.out.print("Enter the upper limit: ");
        int upper = input.nextInt();

        System.out.println("Armstrong numbers between " + lower + " and " + upper + " are:");

        for (int i = lower; i <= upper; i++) {
            int number = i;
            int sum = 0;

            while (number != 0) {
                int digit = number % 10;
                sum += Math.pow(digit, 3);
                number /= 10;
            }

            if (sum == i) {
                System.out.print(i + " ");
            }
        }
    }
}
