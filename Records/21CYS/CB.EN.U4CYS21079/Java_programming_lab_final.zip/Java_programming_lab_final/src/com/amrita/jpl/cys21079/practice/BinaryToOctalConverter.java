package com.amrita.jpl.cys21079.practice;

import java.util.Scanner;

public class BinaryToOctalConverter {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a binary number: ");
        String binary = input.nextLine();

        int decimal = Integer.parseInt(binary, 2);

        String octal = Integer.toOctalString(decimal);

        System.out.println("Octal equivalent of " + binary + " is " + octal);
    }
}
