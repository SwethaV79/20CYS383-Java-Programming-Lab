package com.amrita.jpl.cys21079.pract.net;

import java.io.*;
import java.net.*;

public class Clientsocket {
    /**
     * Client code used to send and receive messages from the server.
     * client is terminated once a exit message is received from the server
     *
     */
    public static void main(String[] args) {
        try {
            Socket s = new Socket("localhost", 2444);

            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            String receivedMessage = "";
            String sendMessage = "";

            while (!receivedMessage.equals("exit")) {
                // Read input from the client console
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
                System.out.print("Client: ");
                sendMessage = br.readLine();

                dos.writeUTF(sendMessage);
                dos.flush();

                receivedMessage = dis.readUTF();
                System.out.println("Server: " + receivedMessage);
            }

            s.close();
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
}
