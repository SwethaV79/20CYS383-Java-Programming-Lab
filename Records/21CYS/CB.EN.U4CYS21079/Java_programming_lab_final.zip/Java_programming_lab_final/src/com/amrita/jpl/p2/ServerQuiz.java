package com.amrita.jpl.p2;

import java.util.Random;

/**
 * ServerQuiz class represents the server-side functionality of a quiz game.
 * ask questions and evaluating answers.
 */
public class ServerQuiz extends QuizGame {
    private QuizGameListener listener;
    private String[] questions = {
            "Tell me count of vowels in english alphabet",
            "Tell me the colour of apple",
    };

    @Override
    public void startGame() {
        System.out.println("game started");
        askQuestion();
    }

    @Override
    /**
     * Asking random questions to the listener
     */
    public void askQuestion() {
        Random random = new Random();
        int index = random.nextInt(questions.length);
        String question = questions[index];

        if (listener != null) {
            listener.onQuestionAsked(question);
        }
    }

    @Override
    public void evaluateAnswer(String answer) {
        boolean isCorrect = false;
        if (answer.equalsIgnoreCase("red")) {
            isCorrect = true;
        }

        if (listener != null) {
            listener.onAnswerEvaluated(isCorrect);
        }
    }

    public void setListener(QuizGameListener listener) {
        this.listener = listener;
    }

    public static void main(String[] args) {
        ServerQuiz server = new ServerQuiz();
        server.startGame();
    }
}