package com.amrita.jpl.cys21079.practice;

import java.util.*;

public class CountDuplicates {

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 4, 5, 6, 6, 6, 7, 8, 8, 9, 9};
        int count = countDuplicates(arr);
        System.out.println("Total number of duplicate elements in the array: " + count);
    }

    public static int countDuplicates(int[] arr) {
        int count = 0;
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < arr.length; i++) {
            if (map.containsKey(arr[i])) {
                map.put(arr[i], map.get(arr[i]) + 1);
            } else {
                map.put(arr[i], 1);
            }
        }
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            if (entry.getValue() > 1) {
                count += entry.getValue() - 1;
            }
        }
        return count;
    }
}
