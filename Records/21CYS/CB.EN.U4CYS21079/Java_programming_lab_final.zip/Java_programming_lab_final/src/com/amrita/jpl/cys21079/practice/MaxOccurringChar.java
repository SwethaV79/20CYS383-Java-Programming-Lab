package com.amrita.jpl.cys21079.practice;

import java.util.*;

public class MaxOccurringChar {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();


        int[] charCount = new int[256];
        for (int i = 0; i < inputString.length(); i++) {
            char c = inputString.charAt(i);
            charCount[c]++;
        }


        int maxCount = 0;
        char maxChar = '\0';
        for (int i = 0; i < 256; i++) {
            if (charCount[i] > maxCount) {
                maxCount = charCount[i];
                maxChar = (char) i;
            }
        }


        System.out.println("Maximum occurring character: " + maxChar);
    }
}
