package com.amrita.jpl.cys21079.practice;

import java.util.Scanner;

public class ArrayInputOutput {

    /**
     * class to get input array elements and display the array
     *
     */

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);


        System.out.print("Enter the size of the array: ");
        int n = input.nextInt();


        int[] arr = new int[n];


        for (int i = 0; i < n; i++) {
            System.out.printf("Enter element %d: ", i);
            arr[i] = input.nextInt();
        }


        System.out.println("The elements of the array are:");
        for (int element : arr) {
            System.out.println(element);
        }

        input.close();
    }

}
