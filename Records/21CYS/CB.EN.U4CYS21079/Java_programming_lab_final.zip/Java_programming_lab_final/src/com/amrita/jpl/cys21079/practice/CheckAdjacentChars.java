package com.amrita.jpl.cys21079.practice;

import java.util.*;

public class CheckAdjacentChars {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the first string: ");
        String str1 = scanner.nextLine();
        System.out.print("Enter the second string: ");
        String str2 = scanner.nextLine();
        System.out.print("Enter the character to check: ");
        char ch = scanner.nextLine().charAt(0);

        boolean areAdjacentCharsSame = checkAdjacentChars(str1, str2, ch);
        if (areAdjacentCharsSame) {
            System.out.println("The character immediately before and after " + ch + " is the same in each string.");
        } else {
            System.out.println("The character immediately before and after " + ch + " is not the same in each string.");
        }
    }

    public static boolean checkAdjacentChars(String str1, String str2, char ch) {
        int index = str1.indexOf(ch);
        if (index == -1) {
            return false;
        }
        if (index == 0 || index == str1.length() - 1) {
            return false;
        }
        if (str1.charAt(index - 1) == str2.charAt(index - 1) && str1.charAt(index + 1) == str2.charAt(index + 1)) {
            return true;
        } else {
            return false;
        }
    }
}
