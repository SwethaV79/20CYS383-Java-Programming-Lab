package com.amrita.jpl.p2;

import java.util.Scanner;

/**
 * client Starts the quiz game by connecting to the server
 */
public class ClientQuiz extends QuizGame implements QuizGameListener {
    private QuizGameServer server;
    private String answer;

    @Override
    public void startGame() {
        connectToServer();
        server.startGame();
    }

    @Override
    public void askQuestion() {
        // Not used in the client
    }

    /**
     * this class Sends the answer to the server for evaluation and displays the result to the client
     */
    @Override
    public void evaluateAnswer(String answer) {
        this.answer = answer;
        server.evaluateAnswer(answer);
    }

    private void connectToServer() {
        server = new QuizGameServer();
        server.setListener(this);
    }

    @Override
    public void onQuestionAsked(String question) {
        System.out.println("Question: " + question);
        System.out.print("Your answer: ");
        Scanner scanner = new Scanner(System.in);
        String answer = scanner.nextLine();
        evaluateAnswer(answer);
    }
    /**
     * Displays whether the answer is correct or not to the client.
     */
    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        if (isCorrect) {
            System.out.println("Correct answer");
        } else {
            System.out.println("Incorrect answer");
        }
    }

    public static void main(String[] args) {
        ClientQuiz client = new ClientQuiz();
        client.startGame();
    }
}