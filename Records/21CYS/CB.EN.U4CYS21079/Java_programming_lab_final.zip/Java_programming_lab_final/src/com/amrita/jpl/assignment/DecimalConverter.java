package com.amrita.jpl.assignment;

import java.util.Scanner;

public class DecimalConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a decimal number: ");
        String decimalInput = scanner.nextLine();

        try {
            int decimal = Integer.parseInt(decimalInput);

            if (decimal < 0) {
                System.out.println("Error: Negative numbers cannot be converted.");
            } else {
                String binary = Integer.toBinaryString(decimal);
                String hexadecimal = Integer.toHexString(decimal);

                System.out.println("Binary: " + binary);
                System.out.println("Hexadecimal: " + hexadecimal);
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid decimal number entered.");
        }
    }
}

