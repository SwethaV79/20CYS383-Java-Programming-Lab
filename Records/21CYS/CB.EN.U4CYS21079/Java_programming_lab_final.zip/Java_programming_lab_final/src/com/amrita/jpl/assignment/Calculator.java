package com.amrita.jpl.assignment;

import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the first number: ");
        double num1 = scanner.nextDouble();

        System.out.print("Enter the second number: ");
        double num2 = scanner.nextDouble();

        System.out.println("Select the operation:");
        System.out.println("1. Addition");
        System.out.println("2. Subtraction");
        System.out.println("3. Multiplication");
        System.out.println("4. Division");

        int operation = scanner.nextInt();

        double result;
        String operationName;

        switch (operation) {
            case 1:
                result = num1 + num2;
                operationName = "Addition";
                break;
            case 2:
                result = num1 - num2;
                operationName = "Subtraction";
                break;
            case 3:
                result = num1 * num2;
                operationName = "Multiplication";
                break;
            case 4:
                if (num2 != 0) {
                    result = num1 / num2;
                    operationName = "Division";
                } else {
                    System.out.println("Error: Division by zero is not allowed.");
                    return;
                }
                break;
            default:
                System.out.println("Error: Invalid operation selected.");
                return;
        }

        System.out.println(operationName + " Result: " + result);
    }
}
